// ===== config.js =====
require('dotenv').config();

module.exports = {
  // Сервер
  PORT: process.env.PORT || 3000,
  HOST: process.env.HOST || '0.0.0.0',
  NODE_ENV: process.env.NODE_ENV || 'development',
  
  // База данных
  DB_PATH: process.env.DB_PATH || './data/smartpass.db',
  
  // API
  API_SECRET: process.env.API_SECRET || 'your-super-secret-key-change-me-12345',
  API_VERSION: process.env.API_VERSION || 'v1',
  API_TIMEOUT: parseInt(process.env.API_TIMEOUT_MS || '5000'),
  
  // Логирование
  LOG_LEVEL: process.env.LOG_LEVEL || 'debug',
  LOG_FILE: process.env.LOG_FILE || './logs/app.log',
  
  // CORS
  CORS_ORIGINS: (process.env.CORS_ORIGINS || 'localhost,127.0.0.1').split(','),
  
  // NTP (синхронизация времени)
  NTP_SERVER: process.env.NTP_SERVER || 'pool.ntp.org',
  NTP_SYNC_INTERVAL: parseInt(process.env.NTP_SYNC_INTERVAL || '3600000'), // 1 час
  
  // Дедупликация
  DEDUP_TIMEOUT_MS: parseInt(process.env.DEDUP_TIMEOUT_MS || '5000'),
  
  // Rate Limiting
  RATE_LIMIT_WINDOW: parseInt(process.env.RATE_LIMIT_WINDOW || '60000'),
  RATE_LIMIT_MAX_REQUESTS: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '300'),
  
  // Валидация
  CARD_UID_MIN_LENGTH: 8,
  CARD_UID_MAX_LENGTH: 20,
  VALID_EVENT_TYPES: ['IN', 'OUT', 'TOGGLE'],
  VALID_USER_ROLES: ['student', 'teacher', 'admin'],
};
