// ===== database.js =====
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const config = require('./config');

const DB_PATH = config.DB_PATH;
const DATA_DIR = path.dirname(DB_PATH);

// Создать директорию если её нет
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

let db;

// Инициализация БД
function initDB() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        console.error('❌ Ошибка БД:', err);
        return reject(err);
      }

      console.log('✓ SQLite БД подключена:', DB_PATH);

      createTables()
        .then(() => resolve(db))
        .catch((e) => reject(e));
    });
  });
}

// Создать таблицы + индексы
function createTables() {
  return new Promise((resolve, reject) => {
    const tables = [
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fullname TEXT NOT NULL,
        role TEXT DEFAULT 'student',
        class TEXT,
        subject TEXT,
        email TEXT UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      `CREATE TABLE IF NOT EXISTS cards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uid TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        event_type TEXT DEFAULT 'TOGGLE',
        active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )`,
      `CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        card_uid TEXT NOT NULL,
        user_id INTEGER,
        event TEXT NOT NULL,
        timestamp DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`,
      `CREATE TABLE IF NOT EXISTS schedule (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class TEXT NOT NULL,
        weekday INTEGER,
        lesson_number INTEGER,
        subject_id INTEGER,
        teacher_id INTEGER,
        room TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      `CREATE TABLE IF NOT EXISTS marks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER,
        teacher_id INTEGER,
        value INTEGER,
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        comment TEXT,
        FOREIGN KEY (student_id) REFERENCES users(id)
      )`,
      `CREATE TABLE IF NOT EXISTS error_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        error_code TEXT,
        message TEXT,
        card_uid TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(timestamp)',
      'CREATE INDEX IF NOT EXISTS idx_attendance_uid ON attendance(card_uid)',
      'CREATE INDEX IF NOT EXISTS idx_cards_uid ON cards(uid)',
      'CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)'
    ];

    db.serialize(() => {
      // Сначала таблицы
      tables.forEach(sql => {
        db.run(sql, (err) => {
          if (err) {
            console.error('❌ Ошибка создания таблицы:', err);
          }
        });
      });

      // Потом индексы
      indexes.forEach(sql => {
        db.run(sql, (err) => {
          if (err) {
            console.error('❌ Ошибка создания индекса:', err);
          }
        });
      });

      resolve();
    });
  });
}

// ===== ATTENDANCE FUNCTIONS =====

function addAttendance(cardUid, event, timestamp) {
  return new Promise((resolve, reject) => {
    const getCard = 'SELECT user_id FROM cards WHERE uid = ? LIMIT 1';
    
    db.get(getCard, [cardUid.toUpperCase()], (err, card) => {
      if (err) reject(err);
      if (!card) {
        reject(new Error('Card not found'));
        return;
      }

      const insert = 'INSERT INTO attendance (card_uid, user_id, event, timestamp) VALUES (?, ?, ?, ?)';
      db.run(insert, [cardUid.toUpperCase(), card.user_id, event, timestamp], function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, card_uid: cardUid, event, timestamp });
      });
    });
  });
}

function getAttendanceByDate(date) {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT a.*, u.fullname, u.role 
      FROM attendance a 
      LEFT JOIN users u ON a.user_id = u.id 
      WHERE DATE(a.timestamp) = ? 
      ORDER BY a.timestamp DESC
    `;
    db.all(query, [date], (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

function getAttendanceByCard(cardUid, limit = 20) {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT a.*, u.fullname, u.role 
      FROM attendance a 
      LEFT JOIN users u ON a.user_id = u.id 
      WHERE a.card_uid = ? 
      ORDER BY a.timestamp DESC 
      LIMIT ?
    `;
    db.all(query, [cardUid.toUpperCase(), limit], (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

function getAttendanceByDateRange(startDate, endDate) {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT a.*, u.fullname, u.role 
      FROM attendance a 
      LEFT JOIN users u ON a.user_id = u.id 
      WHERE DATE(a.timestamp) BETWEEN ? AND ? 
      ORDER BY a.timestamp DESC
    `;
    db.all(query, [startDate, endDate], (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

// ===== CARD FUNCTIONS =====

function addCard(cardUid, userId, eventType = 'TOGGLE') {
  return new Promise((resolve, reject) => {
    const insert = 'INSERT INTO cards (uid, user_id, event_type) VALUES (?, ?, ?)';
    db.run(insert, [cardUid.toUpperCase(), userId, eventType], function(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, uid: cardUid.toUpperCase(), user_id: userId });
    });
  });
}

function getCardByUid(cardUid) {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT c.*, u.fullname, u.role 
      FROM cards c 
      LEFT JOIN users u ON c.user_id = u.id 
      WHERE c.uid = ?
    `;
    db.get(query, [cardUid.toUpperCase()], (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function getAllCards() {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT c.*, u.fullname, u.role 
      FROM cards c 
      LEFT JOIN users u ON c.user_id = u.id 
      ORDER BY c.created_at DESC
    `;
    db.all(query, [], (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

function deleteCard(cardUid) {
  return new Promise((resolve, reject) => {
    const query = 'DELETE FROM cards WHERE uid = ?';
    db.run(query, [cardUid.toUpperCase()], function(err) {
      if (err) reject(err);
      else resolve({ deleted: this.changes });
    });
  });
}

// ===== USER FUNCTIONS =====

function addUser(userData) {
  return new Promise((resolve, reject) => {
    const insert = `
      INSERT INTO users (fullname, role, class, subject, email) 
      VALUES (?, ?, ?, ?, ?)
    `;
    db.run(insert, [
      userData.fullname || 'Unknown',
      userData.role || 'student',
      userData.class || null,
      userData.subject || null,
      userData.email || null
    ], function(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, ...userData });
    });
  });
}

function getUserById(userId) {
  return new Promise((resolve, reject) => {
    const query = 'SELECT * FROM users WHERE id = ?';
    db.get(query, [userId], (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function getAllUsers() {
  return new Promise((resolve, reject) => {
    const query = 'SELECT * FROM users ORDER BY created_at DESC';
    db.all(query, [], (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

function deleteUser(userId) {
  return new Promise((resolve, reject) => {
    const query = 'DELETE FROM users WHERE id = ?';
    db.run(query, [userId], function(err) {
      if (err) reject(err);
      else resolve({ deleted: this.changes });
    });
  });
}

// ===== STATISTICS FUNCTIONS =====

function getPersonOnsite() {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT DISTINCT a.user_id, u.fullname, u.role, MAX(a.timestamp) as last_event, a.event
      FROM attendance a
      LEFT JOIN users u ON a.user_id = u.id
      WHERE a.id IN (
        SELECT MAX(id) FROM attendance GROUP BY user_id
      ) AND a.event = 'IN'
      GROUP BY a.user_id
      ORDER BY a.timestamp DESC
    `;
    db.all(query, [], (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

function getDailyStats(date) {
  return new Promise((resolve, reject) => {
    const queries = {
      total_events: 'SELECT COUNT(*) as count FROM attendance WHERE DATE(timestamp) = ?',
      in_events: 'SELECT COUNT(*) as count FROM attendance WHERE DATE(timestamp) = ? AND event = "IN"',
      out_events: 'SELECT COUNT(*) as count FROM attendance WHERE DATE(timestamp) = ? AND event = "OUT"',
      unique_users: 'SELECT COUNT(DISTINCT user_id) as count FROM attendance WHERE DATE(timestamp) = ?',
      unique_cards: 'SELECT COUNT(DISTINCT card_uid) as count FROM attendance WHERE DATE(timestamp) = ?'
    };

    let stats = {};
    let completed = 0;

    Object.entries(queries).forEach(([key, query]) => {
      db.get(query, [date], (err, row) => {
        if (!err && row) stats[key] = row.count;
        completed++;
        if (completed === Object.keys(queries).length) {
          resolve(stats);
        }
      });
    });
  });
}

// ===== EXPORT =====
module.exports = {
  initDB,
  // Attendance
  addAttendance,
  getAttendanceByDate,
  getAttendanceByCard,
  getAttendanceByDateRange,
  // Cards
  addCard,
  getCardByUid,
  getAllCards,
  deleteCard,
  // Users
  addUser,
  getUserById,
  getAllUsers,
  deleteUser,
  // Stats
  getPersonOnsite,
  getDailyStats
};
