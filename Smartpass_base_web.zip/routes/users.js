// ===== routes/users.js =====
const express = require('express');
const router = express.Router();
const db = require('../database');
const { log } = require('../middleware/logger');

// POST /api/users - Создать пользователя
router.post('/users', async (req, res) => {
  try {
    const { fullname, role, class: cls, subject, email } = req.body;

    if (!fullname) {
      return res.status(400).json({
        status: 'error',
        message: 'Missing required field: fullname',
        code: 'VALIDATION_ERROR'
      });
    }

    const user = await db.addUser({
      fullname,
      role: role || 'student',
      class: cls,
      subject,
      email
    });

    log('INFO', 'User created', { user_id: user.id, fullname });

    return res.status(201).json({
      status: 'success',
      message: 'User created',
      user
    });

  } catch (error) {
    log('ERROR', 'POST /api/users', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/users - Список всех пользователей
router.get('/users', async (req, res) => {
  try {
    const users = await db.getAllUsers();

    return res.json({
      status: 'success',
      total: users.length,
      data: users
    });

  } catch (error) {
    log('ERROR', 'GET /api/users', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/users/:id - Информация о пользователе
router.get('/users/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await db.getUserById(userId);

    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'User not found',
        code: 'USER_NOT_FOUND'
      });
    }

    return res.json({
      status: 'success',
      user
    });

  } catch (error) {
    log('ERROR', 'GET /api/users/:id', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// DELETE /api/users/:id - Удалить пользователя
router.delete('/users/:id', async (req, res) => {
  try {
    const userId = req.params.id;
    
    const user = await db.getUserById(userId);
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'User not found',
        code: 'USER_NOT_FOUND'
      });
    }

    const result = await db.deleteUser(userId);

    log('INFO', 'User deleted', { user_id: userId, fullname: user.fullname });

    return res.json({
      status: 'success',
      message: 'User deleted',
      deleted: result.deleted
    });

  } catch (error) {
    log('ERROR', 'DELETE /api/users/:id', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

module.exports = router;
