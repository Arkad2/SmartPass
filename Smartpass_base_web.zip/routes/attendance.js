// ===== routes/attendance.js =====
const express = require('express');
const router = express.Router();
const db = require('../database');
const config = require('../config');
const { log } = require('../middleware/logger');

const dedupCache = new Map();

// Дедупликация - игнорировать одинаковые события в течение N мс
function isDuplicate(cardUid, event) {
  const key = `${cardUid}-${event}`;
  const now = Date.now();
  const lastTime = dedupCache.get(key) || 0;

  if (now - lastTime < config.DEDUP_TIMEOUT_MS) {
    return true;
  }

  dedupCache.set(key, now);
  return false;
}

// POST /api/attendance - Добавить событие от M5
router.post('/attendance', async (req, res) => {
  try {
    const { card_uid, event, ts } = req.body;
    const timestamp = ts || new Date().toISOString();

    // Валидация
    if (!card_uid || !event) {
      return res.status(400).json({
        status: 'error',
        message: 'Missing card_uid or event',
        code: 'VALIDATION_ERROR'
      });
    }

    if (card_uid.length < config.CARD_UID_MIN_LENGTH || card_uid.length > config.CARD_UID_MAX_LENGTH) {
      return res.status(400).json({
        status: 'error',
        message: `Card UID length must be between ${config.CARD_UID_MIN_LENGTH} and ${config.CARD_UID_MAX_LENGTH}`,
        code: 'INVALID_UID_LENGTH'
      });
    }

    if (!config.VALID_EVENT_TYPES.includes(event)) {
      return res.status(400).json({
        status: 'error',
        message: `Invalid event. Must be one of: ${config.VALID_EVENT_TYPES.join(', ')}`,
        code: 'INVALID_EVENT_TYPE'
      });
    }

    // Проверить дедупликацию
    if (isDuplicate(card_uid, event)) {
      log('DEBUG', 'Duplicate event ignored', { card_uid, event });
      return res.status(201).json({
        status: 'success',
        message: 'Duplicate event ignored',
        duplicate: true
      });
    }

    // Получить информацию о карте
    const card = await db.getCardByUid(card_uid);
    if (!card) {
      log('WARN', 'Card not found', { card_uid });
      return res.status(404).json({
        status: 'error',
        message: 'Card not found',
        code: 'CARD_NOT_FOUND',
        card_uid
      });
    }

    // Добавить событие
    const record = await db.addAttendance(card_uid, event, timestamp);

    log('INFO', 'Attendance recorded', {
      card_uid,
      user: card.fullname,
      event,
      timestamp
    });

    return res.status(201).json({
      status: 'success',
      message: `${event} event recorded`,
      record,
      user: {
        id: card.user_id,
        fullname: card.fullname,
        role: card.role
      },
      serverTime: new Date().toISOString()
    });

  } catch (error) {
    log('ERROR', 'POST /api/attendance', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/attendance?date=2025-12-09 - История по дате
router.get('/attendance', async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().split('T')[0];

    // Валидация даты
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid date format. Use YYYY-MM-DD',
        code: 'INVALID_DATE_FORMAT'
      });
    }

    const records = await db.getAttendanceByDate(date);

    return res.json({
      status: 'success',
      date,
      total: records.length,
      data: records
    });

  } catch (error) {
    log('ERROR', 'GET /api/attendance', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/attendance/:uid - История по карте
router.get('/attendance/:uid', async (req, res) => {
  try {
    const uid = req.params.uid;
    const limit = parseInt(req.query.limit || '20');

    const card = await db.getCardByUid(uid);
    if (!card) {
      return res.status(404).json({
        status: 'error',
        message: 'Card not found',
        code: 'CARD_NOT_FOUND'
      });
    }

    const history = await db.getAttendanceByCard(uid, limit);

    return res.json({
      status: 'success',
      card: {
        uid: card.uid,
        user_id: card.user_id,
        fullname: card.fullname
      },
      total: history.length,
      history
    });

  } catch (error) {
    log('ERROR', 'GET /api/attendance/:uid', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

module.exports = router;
