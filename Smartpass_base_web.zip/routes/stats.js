// ===== routes/stats.js =====
const express = require('express');
const router = express.Router();
const db = require('../database');
const { log } = require('../middleware/logger');

// GET /api/stats/:date - Статистика за день
router.get('/stats/:date', async (req, res) => {
  try {
    const date = req.params.date;

    // Валидация даты
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid date format. Use YYYY-MM-DD',
        code: 'INVALID_DATE_FORMAT'
      });
    }

    const stats = await db.getDailyStats(date);

    return res.json({
      status: 'success',
      date,
      stats
    });

  } catch (error) {
    log('ERROR', 'GET /api/stats/:date', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/stats/range?start=2025-12-01&end=2025-12-09 - Статистика за период
router.get('/stats/range', async (req, res) => {
  try {
    const { start, end } = req.query;

    if (!start || !end) {
      return res.status(400).json({
        status: 'error',
        message: 'Missing query parameters: start, end (YYYY-MM-DD)',
        code: 'VALIDATION_ERROR'
      });
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
      return res.status(400).json({
        status: 'error',
        message: 'Invalid date format. Use YYYY-MM-DD',
        code: 'INVALID_DATE_FORMAT'
      });
    }

    const records = await db.getAttendanceByDateRange(start, end);

    // Расчет статистики за период
    const stats = {
      start_date: start,
      end_date: end,
      total_events: records.length,
      in_events: records.filter(r => r.event === 'IN').length,
      out_events: records.filter(r => r.event === 'OUT').length,
      unique_users: new Set(records.map(r => r.user_id)).size,
      unique_cards: new Set(records.map(r => r.card_uid)).size,
      events_by_date: {}
    };

    // Группировка по дате
    records.forEach(record => {
      const date = record.timestamp.split('T')[0];
      if (!stats.events_by_date[date]) {
        stats.events_by_date[date] = { total: 0, in: 0, out: 0 };
      }
      stats.events_by_date[date].total++;
      if (record.event === 'IN') {
        stats.events_by_date[date].in++;
      } else {
        stats.events_by_date[date].out++;
      }
    });

    return res.json({
      status: 'success',
      stats,
      total_records: records.length
    });

  } catch (error) {
    log('ERROR', 'GET /api/stats/range', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/stats/onsite - Кто сейчас в офисе
router.get('/stats/onsite', async (req, res) => {
  try {
    const peopleOnsite = await db.getPersonOnsite();

    return res.json({
      status: 'success',
      count: peopleOnsite.length,
      people: peopleOnsite
    });

  } catch (error) {
    log('ERROR', 'GET /api/stats/onsite', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

module.exports = router;
