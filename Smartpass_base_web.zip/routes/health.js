// ===== routes/health.js =====
const express = require('express');
const router = express.Router();
const config = require('../config');
const { log } = require('../middleware/logger');

// GET /api/health - Проверка статуса
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'SmartPass API is running',
    version: config.API_VERSION,
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: config.NODE_ENV
  });
});

// GET /api/version - Версия API
router.get('/version', (req, res) => {
  res.json({
    status: 'ok',
    version: config.API_VERSION,
    name: 'SmartPass Backend API',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
