// ===== routes/cards.js =====
const express = require('express');
const router = express.Router();
const db = require('../database');
const config = require('../config');
const { log } = require('../middleware/logger');

// POST /api/cards - Добавить карту
router.post('/cards', async (req, res) => {
  try {
    const { card_uid, user_id, event_type } = req.body;

    if (!card_uid || !user_id) {
      return res.status(400).json({
        status: 'error',
        message: 'Missing required fields: card_uid, user_id',
        code: 'VALIDATION_ERROR'
      });
    }

    // Валидация UID
    if (card_uid.length < config.CARD_UID_MIN_LENGTH || card_uid.length > config.CARD_UID_MAX_LENGTH) {
      return res.status(400).json({
        status: 'error',
        message: `Card UID length must be between ${config.CARD_UID_MIN_LENGTH} and ${config.CARD_UID_MAX_LENGTH}`,
        code: 'INVALID_UID_LENGTH'
      });
    }

    // Проверить пользователя
    const user = await db.getUserById(user_id);
    if (!user) {
      return res.status(404).json({
        status: 'error',
        message: 'User not found',
        code: 'USER_NOT_FOUND'
      });
    }

    // Добавить карту
    const card = await db.addCard(card_uid, user_id, event_type || 'TOGGLE');

    log('INFO', 'Card added', { card_uid, user_id, user: user.fullname });

    return res.status(201).json({
      status: 'success',
      message: 'Card added',
      card,
      user: {
        id: user.id,
        fullname: user.fullname
      }
    });

  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return res.status(409).json({
        status: 'error',
        message: 'Card UID already exists',
        code: 'CARD_ALREADY_EXISTS'
      });
    }

    log('ERROR', 'POST /api/cards', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/cards - Список всех карт
router.get('/cards', async (req, res) => {
  try {
    const cards = await db.getAllCards();

    return res.json({
      status: 'success',
      total: cards.length,
      data: cards
    });

  } catch (error) {
    log('ERROR', 'GET /api/cards', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// GET /api/cards/:uid - Информация о карте
router.get('/cards/:uid', async (req, res) => {
  try {
    const uid = req.params.uid;
    const card = await db.getCardByUid(uid);

    if (!card) {
      return res.status(404).json({
        status: 'error',
        message: 'Card not found',
        code: 'CARD_NOT_FOUND'
      });
    }

    return res.json({
      status: 'success',
      card
    });

  } catch (error) {
    log('ERROR', 'GET /api/cards/:uid', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

// DELETE /api/cards/:uid - Удалить карту
router.delete('/cards/:uid', async (req, res) => {
  try {
    const uid = req.params.uid;
    
    const card = await db.getCardByUid(uid);
    if (!card) {
      return res.status(404).json({
        status: 'error',
        message: 'Card not found',
        code: 'CARD_NOT_FOUND'
      });
    }

    const result = await db.deleteCard(uid);

    log('INFO', 'Card deleted', { card_uid: uid });

    return res.json({
      status: 'success',
      message: 'Card deleted',
      deleted: result.deleted
    });

  } catch (error) {
    log('ERROR', 'DELETE /api/cards/:uid', { error: error.message });
    return res.status(500).json({
      status: 'error',
      message: error.message,
      code: 'INTERNAL_ERROR'
    });
  }
});

module.exports = router;
