// ===== server.js =====
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const config = require('./config');
const db = require('./database');
const { log, middleware: loggerMiddleware } = require('./middleware/logger');
const authMiddleware = require('./middleware/auth');
const rateLimitMiddleware = require('./middleware/rateLimit');

const attendanceRoutes = require('./routes/attendance');
const cardsRoutes = require('./routes/cards');
const usersRoutes = require('./routes/users');
const statsRoutes = require('./routes/stats');
const healthRoutes = require('./routes/health');

const app = express();

// ===== MIDDLEWARE =====

// CORS конфигурация
app.use(cors({
  origin: (origin, callback) => {
    // Проверка wildcard patterns
    const allowedPatterns = config.CORS_ORIGINS.map(o => {
      if (o.includes('*')) {
        return new RegExp('^' + o.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$');
      }
      return o;
    });

    if (!origin || allowedPatterns.some(p => {
      if (p instanceof RegExp) return p.test(origin);
      return p === origin;
    })) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// Body parser
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));

// Логирование
app.use(loggerMiddleware);

// Rate limiting
app.use(rateLimitMiddleware);

// Аутентификация
app.use(authMiddleware);

// ===== ROUTES =====

// API v1
app.use(`/api/${config.API_VERSION}`, attendanceRoutes);
app.use(`/api/${config.API_VERSION}`, cardsRoutes);
app.use(`/api/${config.API_VERSION}`, usersRoutes);
app.use(`/api/${config.API_VERSION}`, statsRoutes);
app.use(`/api/${config.API_VERSION}`, healthRoutes);

// Legacy API (без версии)
app.use('/api', attendanceRoutes);
app.use('/api', cardsRoutes);
app.use('/api', usersRoutes);
app.use('/api', statsRoutes);
app.use('/api', healthRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'SmartPass Backend API',
    version: config.API_VERSION,
    status: 'running',
    endpoints: {
      health: '/api/health',
      attendance: {
        post: '/api/attendance',
        get: '/api/attendance?date=YYYY-MM-DD',
        byCard: '/api/attendance/:uid'
      },
      cards: {
        post: '/api/cards',
        get: '/api/cards',
        byUid: '/api/cards/:uid',
        delete: '/api/cards/:uid'
      },
      users: {
        post: '/api/users',
        get: '/api/users',
        byId: '/api/users/:id',
        delete: '/api/users/:id'
      },
      stats: {
        daily: '/api/stats/:date',
        range: '/api/stats/range?start=YYYY-MM-DD&end=YYYY-MM-DD',
        onsite: '/api/stats/onsite'
      }
    }
  });
});

// ===== ERROR HANDLING =====

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    status: 'error',
    message: 'Route not found',
    path: req.path,
    code: 'NOT_FOUND'
  });
});

// Error Handler
app.use((err, req, res, next) => {
  log('ERROR', 'Unhandled error', { 
    message: err.message,
    stack: err.stack,
    path: req.path
  });

  res.status(err.status || 500).json({
    status: 'error',
    message: err.message || 'Internal server error',
    code: 'INTERNAL_ERROR'
  });
});

// ===== INITIALIZATION =====

async function initializeServer() {
  try {
    log('INFO', '🚀 Инициализация SmartPass Backend...');

    // Подключить БД
    await db.initDB();
    log('INFO', '✓ База данных инициализирована');

    // Создать тестовые данные при первом запуске
    const users = await db.getAllUsers();
    if (users.length === 0) {
      log('INFO', 'Создаю тестовые данные...');
      
      const user1 = await db.addUser({
        fullname: 'Иван Петров',
        role: 'student',
        class: '7A',
        email: 'ivan@example.com'
      });

      const user2 = await db.addUser({
        fullname: 'Мария Сидорова',
        role: 'teacher',
        subject: 'Математика',
        email: 'maria@example.com'
      });

      await db.addCard('04F1A21A', user1.id, 'TOGGLE');
      await db.addCard('04F1A21B', user2.id, 'TOGGLE');

      log('INFO', '✓ Тестовые данные созданы');
    }

    // Запустить сервер
    const PORT = config.PORT;
    const HOST = config.HOST === '0.0.0.0' ? 'localhost' : config.HOST;

    app.listen(PORT, config.HOST, () => {
      log('INFO', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      log('INFO', '🔐 SmartPass Backend API');
      log('INFO', `✓ Сервер запущен на http://${HOST}:${PORT}`);
      log('INFO', `✓ Версия API: ${config.API_VERSION}`);
      log('INFO', `✓ Окружение: ${config.NODE_ENV}`);
      log('INFO', `✓ База данных: ${config.DB_PATH}`);
      log('INFO', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      log('INFO', 'Доступные endpoint\'ы:');
      log('INFO', `  Health: http://${HOST}:${PORT}/api/health`);
      log('INFO', `  POST POST /api/attendance - Приём событий от M5`);
      log('INFO', `  POST /api/users - Создать пользователя`);
      log('INFO', `  POST /api/cards - Привязать карту`);
      log('INFO', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    });

  } catch (error) {
    log('ERROR', 'Ошибка инициализации сервера', { error: error.message });
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', () => {
  log('INFO', 'Сервер завершает работу...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('INFO', 'Сервер был остановлен');
  process.exit(0);
});

// Запуск
initializeServer();

module.exports = app;
