// ===== middleware/rateLimit.js =====
const config = require('../config');

const requestCounts = new Map();

function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const window = config.RATE_LIMIT_WINDOW;
  const maxRequests = config.RATE_LIMIT_MAX_REQUESTS;

  if (!requestCounts.has(ip)) {
    requestCounts.set(ip, []);
  }

  let requests = requestCounts.get(ip);
  
  // Удалить старые запросы за пределами окна
  requests = requests.filter(time => now - time < window);
  
  if (requests.length >= maxRequests) {
    return res.status(429).json({
      status: 'error',
      message: 'Too many requests',
      code: 'RATE_LIMIT_EXCEEDED',
      retryAfter: Math.ceil(window / 1000)
    });
  }

  requests.push(now);
  requestCounts.set(ip, requests);
  
  next();
}

// Очистка старых записей каждый час
setInterval(() => {
  const now = Date.now();
  const window = config.RATE_LIMIT_WINDOW;
  
  for (const [ip, requests] of requestCounts.entries()) {
    const filtered = requests.filter(time => now - time < window);
    if (filtered.length === 0) {
      requestCounts.delete(ip);
    } else {
      requestCounts.set(ip, filtered);
    }
  }
}, 60000); // каждую минуту

module.exports = rateLimit;
