// ===== middleware/logger.js =====
const fs = require('fs');
const path = require('path');
const config = require('../config');

const LOG_FILE = config.LOG_FILE;
const LOG_DIR = path.dirname(LOG_FILE);

// Создать директорию логов
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

function log(level, message, data = {}) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    level,
    message,
    ...data
  };

  const logLine = `[${timestamp}] [${level}] ${message}${Object.keys(data).length > 0 ? ' ' + JSON.stringify(data) : ''}\n`;

  // Вывести в консоль
  const colors = {
    ERROR: '\x1b[31m',
    WARN: '\x1b[33m',
    INFO: '\x1b[32m',
    DEBUG: '\x1b[36m',
    RESET: '\x1b[0m'
  };

  if (config.LOG_LEVEL === 'debug' || level !== 'DEBUG') {
    console.log(colors[level] + logLine.trim() + colors.RESET);
  }

  // Записать в файл
  fs.appendFileSync(LOG_FILE, logLine);
}

function middleware(req, res, next) {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    log('INFO', `${req.method} ${req.path}`, {
      status: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip
    });
  });

  next();
}

module.exports = { log, middleware };
