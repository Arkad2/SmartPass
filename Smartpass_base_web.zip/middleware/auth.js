// ===== middleware/auth.js =====
const config = require('../config');

function authenticateToken(req, res, next) {
  // Получить токен из заголовка
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // "Bearer TOKEN"

  // Список endpoint'ов, для которых аутентификация необязательна
  const publicEndpoints = [
    '/api/health',
    '/api/version',
    '/api/attendance',
    '/api/stats'
  ];

  // Проверить, является ли текущий путь публичным
  const isPublic = publicEndpoints.some(ep => req.path.includes(ep));
  
  if (isPublic) {
    return next();
  }

  // Для приватных endpoint'ов проверить токен
  if (!token) {
    return res.status(401).json({
      status: 'error',
      message: 'Missing authorization token',
      code: 'AUTH_MISSING'
    });
  }

  if (token !== config.API_SECRET) {
    return res.status(403).json({
      status: 'error',
      message: 'Invalid authorization token',
      code: 'AUTH_INVALID'
    });
  }

  next();
}

module.exports = authenticateToken;
